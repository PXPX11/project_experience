# -*- coding: utf-8 -*-
import scrapy
from week01.items import Week01Item
from scrapy.selector import  Selector


class MaoyanSpider(scrapy.Spider):
    name = 'maoyan'
    allowed_domains = ['maoyan.com']
    start_urls = ['https://maoyan.com/films?showType=3offset=0']

    def start_requests(self):
        for i in range(1):
            url = 'https://maoyan.com/films?showType=3&offset='+str(30*i)
            yield scrapy.Request(url=url , callback=self.parse)

    def parse(self, response):

        movies = Selector(response=response).xpath("//div[@class=\"movie-hover-info\"]")
        for movie in movies:
            item = Week01Item()
            name = movie.xpath('./div[1]/span/text()').extract()
            classification = movie.xpath('./div[2]/text()').extract()[1].strip('\n').strip()
            display_time = movie.xpath('./div[4]/text()').extract()[1].strip('\n').strip()
            item['name'] = name
            item['classification'] = classification
            item['display_time']  = display_time
            yield  item
