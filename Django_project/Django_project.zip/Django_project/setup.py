import os
import schedule


def job():
    os.system('cd jdqps && scrapy crawl jd --nolog')

schedule.every().day.at('08:30').do(job)