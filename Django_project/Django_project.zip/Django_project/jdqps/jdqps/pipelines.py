# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pandas

import pandas as pd
from .DB import ConnDB

comments = []
class JdqpsPipeline:
    def __init__(self):
        self.dbInfo = {
            'host': 'localhost',
            'port': 3306,
            'user': 'root',
            'password': 'root',
            'db': 'movie'
        }

    def process_item(self, item, spider):

        comments.append([item['comment'],item['creat_time'],item['atitude']])

    def close_spider(self,spider):
        sql0 = ['truncate final.`t1`;']
        db = ConnDB(self.dbInfo, sql0)
        db.run()
        data = pd.DataFrame(comments)
        data.drop_duplicates()
        data = list(data.values)
        for comment in data:
            sql = ['insert into final.`t1`( `comments`, `creat_time`, `sentiments`) values (\'' + str(comment[0]) + '\',\'' + str(comment[1]) + '\',\'' + str(comment[2]) + '\');']
            db = ConnDB(self.dbInfo, sql)
            db.run()
