# -*- coding: utf-8 -*-
import scrapy,json,time
from ..items import JdqpsItem
from bs4 import BeautifulSoup
import snownlp
from datetime import datetime


class JdSpider(scrapy.Spider):
    name = 'jd'


    def start_requests(self):
        url = "https://search.jd.com/Search?keyword=%E6%B0%94%E6%B3%A1%E6%B0%B4&enc=utf-8&wq=qi%27pao%27shui"
        yield scrapy.Request(url,callback=self.GetComment)


    def GetProductId(self,response):
        ProductList = []
        soup = BeautifulSoup(response.body_as_unicode(),'html.parser')
        items = soup.find_all('div',class_='gl-i-wrap')
        for item in items[:10]:
            ProductId = item.find(class_="p-price")
            ProductId = ProductId.find('strong')['class'][0][2:]
            ProductList.append(ProductId)
        return ProductList



    def GetComment(self,response):
        ProductList = self.GetProductId(response)
        print(ProductList)
        for pid in ProductList:
            for i in range(0,100):
                url = f"https://club.jd.com/comment/productPageComments.action?productId={pid}&score=0&sortType=5&page="+str(i+1)+"&pageSize=10&isShadowSku=0&rid=0&fold=1"
                yield scrapy.Request(url=url,callback=self.parse)

    def parse(self, response):
        item = JdqpsItem()
        time.sleep(0.5)
        js = json.loads(response.body_as_unicode())
        comments = js['comments']
        for comment in comments:
            content = comment['content']
            create_time = int(time.mktime(datetime.strptime(comment['creationTime'],'%Y-%m-%d %H:%M:%S').timetuple()))
            atitude = snownlp.SnowNLP(content).sentiments
            item['comment'] = content
            item['creat_time'] = create_time
            item['atitude'] = atitude
            print(content,create_time,atitude)
            yield item

