from django.shortcuts import render
import time
from datetime import datetime
# Create your views here.
from .models import T1
from django.db.models import Avg

def books_short(request):
    ###  从models取数据传给template  ###
    shorts = T1.objects.all()
    # 评论数量
    counter = T1.objects.all().count()

    # 平均星级
    # star_value = T1.objects.values('n_star')
    # star_avg =f" {T1.objects.aggregate(Avg('n_start'))['n_start__avg']:0.1f} "
    # 情感倾向
    sent_avg =f" {T1.objects.aggregate(Avg('sentiments'))['sentiments__avg']:0.2f} "

    # 正向数量
    queryset = T1.objects.values('sentiments')
    condtions = {'sentiments__gte': 0.5}
    plus = queryset.filter(**condtions).count()

    # 负向数量
    queryset = T1.objects.values('sentiments')
    condtions = {'sentiments__lt': 0.5}
    minus = queryset.filter(**condtions).count()

    # return render(request, 'douban.html', locals())
    return render(request, 'result.html', locals())

def search(request):

    key_word = request.GET.get('keywords')
    queryset = T1.objects.all()
    conditions = {}
    if request.GET.get('date_end'):
        date_end = int(time.mktime(datetime.strptime(request.GET.get('date_end'), '%Y-%m-%d').timetuple()))
        conditions['creat_time__lte'] = date_end
    if request.GET.get('date_start'):
        date_start = int(time.mktime(datetime.strptime(request.GET.get('date_start'), '%Y-%m-%d').timetuple()))
        conditions['creat_time__gte'] = date_start
    if key_word:
        conditions['comments__icontains'] = key_word
    shorts = queryset.filter(**conditions)
    counter = shorts.count()
    # 情感倾向
    sent_avg =f" {shorts.aggregate(Avg('sentiments'))['sentiments__avg']:0.2f} "

    # 正向数量
    queryset = shorts.values('sentiments')
    condtions = {'sentiments__gte': 0.5}
    plus = queryset.filter(**condtions).count()

    # 负向数量
    queryset = shorts.values('sentiments')
    condtions = {'sentiments__lt': 0.5}
    minus = queryset.filter(**condtions).count()
    return render(request,'result.html',locals())