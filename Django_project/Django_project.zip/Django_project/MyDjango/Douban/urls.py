from django.urls import path
from . import views


urlpatterns = [
    path('', views.books_short),
    path('search/', views.search, name='search')
]
app_name='Douban'
